# نظام تقارير الأمن والسلامة

## تشغيل محلي
```bash
pip install -r requirements.txt
python app.py
```

ثم افتح:
- `/` صفحة المشرف
- `/admin` لوحة المدير

بيانات الدخول الافتراضية:
- admin
- 123456

## النشر أونلاين
ارفع المشروع إلى خدمة تدعم Python/Flask مثل Render أو Railway.
بعد النشر اضبط متغيرات البيئة:
- SECRET_KEY
- ADMIN_USER
- ADMIN_PASSWORD

ملاحظة: SQLite مناسب للتجربة. للإنتاج يفضّل PostgreSQL كقاعدة بيانات سحابية مشتركة.
