from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, io
from datetime import datetime, date
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

app=Flask(__name__)
app.secret_key=os.environ.get("SECRET_KEY","change-this-secret-key")
DB=os.environ.get("DATABASE_PATH","reports.db")
ADMIN_USER=os.environ.get("ADMIN_USER","admin")
ADMIN_PASSWORD=os.environ.get("ADMIN_PASSWORD","123456")

def db():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row; return con

def init():
    con=db()
    con.execute("""CREATE TABLE IF NOT EXISTS reports(
      id INTEGER PRIMARY KEY AUTOINCREMENT, supervisor TEXT NOT NULL, report_date TEXT NOT NULL,
      shift TEXT, location TEXT, status TEXT, rounds INTEGER DEFAULT 0, incidents INTEGER DEFAULT 0,
      assaults INTEGER DEFAULT 0, power_outages INTEGER DEFAULT 0, visitors INTEGER DEFAULT 0,
      elevator_faults INTEGER DEFAULT 0, supervisor_minutes INTEGER DEFAULT 0,
      details TEXT, actions TEXT, created_at TEXT NOT NULL)""")
    con.commit(); con.close()

init()

@app.route("/", methods=["GET","POST"])
def report():
    if request.method=="POST":
        f=request.form
        con=db()
        con.execute("""INSERT INTO reports(supervisor,report_date,shift,location,status,rounds,incidents,assaults,power_outages,visitors,elevator_faults,supervisor_minutes,details,actions,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (f["supervisor"],f["report_date"],f.get("shift"),f.get("location"),f.get("status"),
         int(f.get("rounds") or 0),int(f.get("incidents") or 0),int(f.get("assaults") or 0),
         int(f.get("power_outages") or 0),int(f.get("visitors") or 0),int(f.get("elevator_faults") or 0),
         int(f.get("supervisor_minutes") or 0),f.get("details"),f.get("actions"),datetime.now().isoformat()))
        con.commit(); con.close()
        return render_template("report.html",success=True,today=date.today().isoformat())
    return render_template("report.html",success=False,today=date.today().isoformat())

@app.route("/admin/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        if request.form.get("username")==ADMIN_USER and request.form.get("password")==ADMIN_PASSWORD:
            session["admin"]=True; return redirect(url_for("dashboard"))
        return render_template("login.html",error="بيانات الدخول غير صحيحة")
    return render_template("login.html")

def protected():
    return bool(session.get("admin"))

@app.route("/admin")
def dashboard():
    if not protected(): return redirect(url_for("login"))
    con=db(); rows=con.execute("SELECT * FROM reports ORDER BY id DESC").fetchall()
    today=date.today().isoformat(); month=today[:7]
    def total(field): return con.execute(f"SELECT COALESCE(SUM({field}),0) FROM reports").fetchone()[0]
    stats={
      "today":con.execute("SELECT COUNT(*) FROM reports WHERE report_date=?",(today,)).fetchone()[0],
      "month":con.execute("SELECT COUNT(*) FROM reports WHERE substr(report_date,1,7)=?",(month,)).fetchone()[0],
      "total":len(rows),"follow":con.execute("SELECT COUNT(*) FROM reports WHERE status!='طبيعية'").fetchone()[0],
      "assaults":total("assaults"),"power":total("power_outages"),"visitors":total("visitors"),
      "elevators":total("elevator_faults"),"minutes":total("supervisor_minutes")}
    con.close()
    return render_template("dashboard.html",rows=rows,stats=stats)

@app.route("/admin/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/report/<int:rid>/pdf")
def report_pdf(rid):
    if not protected(): return redirect(url_for("login"))
    con=db(); r=con.execute("SELECT * FROM reports WHERE id=?",(rid,)).fetchone(); con.close()
    if not r: return "Not found",404
    buf=io.BytesIO(); c=canvas.Canvas(buf,pagesize=A4); w,h=A4; y=h-45
    c.setFont("Helvetica-Bold",16); c.drawCentredString(w/2,y,"Security & Safety Daily Report"); y-=35
    fields=[("Report ID",r["id"]),("Date",r["report_date"]),("Supervisor",r["supervisor"]),("Shift",r["shift"]),
    ("Location",r["location"]),("Status",r["status"]),("Rounds",r["rounds"]),("Incidents",r["incidents"]),
    ("Assaults",r["assaults"]),("Power faults",r["power_outages"]),("Visitors",r["visitors"]),
    ("Elevator faults",r["elevator_faults"]),("Supervisor minutes",r["supervisor_minutes"]),
    ("Details",r["details"]),("Actions",r["actions"])]
    c.setFont("Helvetica",10)
    for k,v in fields:
        text=f"{k}: {v or '-'}"
        for line in textwrap.wrap(text,95):
            c.drawString(45,y,line); y-=16
            if y<45: c.showPage(); y=h-45; c.setFont("Helvetica",10)
    c.save(); buf.seek(0)
    return send_file(buf,as_attachment=True,download_name=f"report-{rid}.pdf",mimetype="application/pdf")

@app.route("/api/stats")
def api_stats():
    if not protected(): return jsonify({"error":"unauthorized"}),401
    con=db(); rows=con.execute("SELECT * FROM reports ORDER BY id DESC").fetchall(); con.close()
    return jsonify([dict(x) for x in rows])

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)))
